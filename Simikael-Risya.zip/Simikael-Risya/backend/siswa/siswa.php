<?php
include '../connect.php';
session_start();

$allowed_roles = ['admin'];

if (!isset($_SESSION['id_user']) || !in_array($_SESSION['role'], $allowed_roles)) {
  header("Location: ../../login/sign-in-up.php"); 
  exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nis'])) {
    $id_siswa = trim($_POST['id_siswa']);
    $nama_siswa = trim($_POST['nama_siswa']);
    $nis = trim($_POST['nis']);
    $kelas = trim($_POST['kelas']);
    $jurusan = trim($_POST['jurusan']);
    $id_user = trim($_POST['id_user']);

    if ($id_siswa && $nama_siswa && $nis && $kelas && $jurusan && $id_user) {
      
        $stmt = $conn->prepare("INSERT INTO siswa (id_siswa, nama_siswa, nis, kelas, jurusan, id_user) 
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
        nama_siswa = VALUES(nama_siswa), 
        nis = VALUES(nis), 
        kelas = VALUES(kelas), 
        jurusan = VALUES(jurusan), 
        id_user = VALUES(id_user)");

        $stmt->bind_param("issssi", $id_siswa, $nama_siswa, $nis, $kelas, $jurusan, $id_user);
        if ($stmt->execute()) {
            echo "<script>alert('Data siswa berhasil ditambahkan atau diperbarui!');</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}

$query = "SELECT * FROM siswa";
$result = mysqli_query($conn, $query);
?>


<!DOCTYPE html>
<html>
<head>
<title>Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">

</head>
<body>

<div class="sidebar">
  <div class="brand">𝕊𝕀𝕄𝕀𝕂✮𝔼𝕃</div>
  <a class="active" href="../dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
  <a href="../pengajuan/pengajuan.php"><i class="fa-solid fa-file-alt"></i>Pengajuan</a>
  <a href="../industri/industri.php"><i class="fa-solid fa-industry"></i> Industri</a>
  <a href="siswa.php"><i class="fa-solid fa-user-graduate"></i> Siswa</a>
  <a href="../guru/guru.php"><i class="fa-solid fa-chalkboard-user"></i></i> Guru</a>
  <a href="../user/user.php"><i class="fa-solid fa-users"></i> Users</a>
  <a class="logout" href="../../login/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
  <h1>Siswa</h1>
  <p>Anda bisa mengontrol produk melalui ini.</p>
  <button class="btn add" id="add-btn">Tambah</button>
  <a href="../../export_pdf/pdf_siswa.php" class="btn export">Export PDF</a>

</div>
<div id="overlay"></div>
<div id="form-container">
<form action="siswa.php" method="POST" enctype="multipart/form-data">
    <div class="form-row">
        <label for="id_siswa">ID Siswa</label>
        <input type="number" name="id_siswa" id="id_siswa" required>
    </div>

    <div class="form-row">
        <label for="nama_siswa">Nama Siswa</label>
        <input type="text" name="nama_siswa" id="nama_siswa" required>
    </div>

    <div class="form-row">
        <label for="nis">NIS</label>
        <input type="number" name="nis" id="nis" required>
    </div>

    <div class="form-row">
        <label for="kelas">Kelas</label>
        <input type="text" name="kelas" id="kelas" required>
    </div>

    <div class="form-row">
        <label for="jurusan">Jurusan</label>
        <input type="text" name="jurusan" id="jurusan" required>
    </div>

    <div class="form-row">
        <label for="id_user">ID User</label>
        <input type="number" name="id_user" id="id_user" required>
    </div>

    <div class="form-actions">
        <button type="submit">Upload Data</button>
        <button type="button" class="close-popup" id="close-btn">Close</button>
    </div>
</form>
</div>

<table id="data-table">
  <thead>
    <tr>
      <th>No</th>
      <th>ID Siswa</th>
      <th>Nama Siswa</th>
      <th>NIS</th>
      <th>Kelas</th>
      <th>Jurusan</th>
      <th>ID User</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
      ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['id_siswa'] ?></td>
        <td><?= $row['nama_siswa'] ?></td>
        <td><?= $row['nis'] ?></td>
        <td><?= $row['kelas'] ?></td>
        <td><?= $row['jurusan'] ?></td>
        <td><?= $row['id_user'] ?></td>
        <td>
          <a href="detail.php?id=<?= $row['id_siswa'] ?>" class="btn btn-detail">Detail</a>
          <a href="#" class="btn btn-edit" data-id="<?= $row['id_siswa'] ?>">Edit</a>
          <a style="text-decoration:none" href="del.php?id=<?= $row['id_siswa'] ?>" class="btn btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Delete</a>
        </td>
      </tr>
    <?php } ?>
  </tbody>
</table>

<!-- edit -->
<div id="overlay"></div>
<div class="edit-form">
<h1 style="color: red;">Edit Form</h1>
    <form action="siswa_edit.php?id=<?php echo $row['id_siswa']; ?>" method="POST">
        <label for="id_siswa">ID Siswa</label>
        <input type="number" name="id_siswa" id="id_siswa" required>

        <label for="nama_siswa">Nama Siswa</label>
        <input type="text" name="nama_siswa" id="nama_siswa" required>

        <label for="nis">NIS</label>
        <input type="number" name="nis" id="nis" required>

        <label for="kelas">Kelas</label>
        <input type="text" name="kelas" id="kelas" required>

        <label for="jurusan">Jurusan</label>
        <input type="text" name="jurusan" id="jurusan" required>

        <label for="id_user">ID User</label>
        <input type="number" name="id_user" id="id_user" required>

        <button type="submit">Update Data</button>
        <a href="siswa.php" class="close-popup">Kembali</a>
    </form>
</div>

<script>
//   POPUP ADD
  const addBtn = document.getElementById('add-btn');
  const formContainer = document.getElementById('form-container');
  const overlay = document.getElementById('overlay');
  const closeBtn = document.getElementById('close-btn');

    addBtn.addEventListener('click', function() {
    formContainer.style.display = 'block';
    overlay.style.display = 'block';
  });

  closeBtn.addEventListener('click', function() {
    formContainer.style.display = 'none';
    overlay.style.display = 'none';
  });

  closeBtn.style.display = 'none';

  overlay.addEventListener('click', function() {
    formContainer.style.display = 'none';
    overlay.style.display = 'none';
  });

// POPUP EDIT
  document.addEventListener('DOMContentLoaded', () => {
    const editForm = document.querySelector('.edit-form');
    const overlay = document.getElementById('overlay');
    const editButtons = document.querySelectorAll('.btn-edit');
    const closePopupButton = document.querySelector('.edit-form .close-popup');

  editButtons.forEach(button => {
  button.addEventListener('click', (event) => {
  event.preventDefault();
  const productId = button.getAttribute('data-id');

  fetch(`edit.php?id=${productId}`)
  .then(response => response.text())
  .then(html => {
    editForm.innerHTML = html;
    editForm.style.display = 'block';
    overlay.style.display = 'block';
        });
    });
});

closePopupButton.addEventListener('click', () => {
    editForm.style.display = 'none';
    overlay.style.display = 'none';
  });

overlay.addEventListener('click', () => {
    editForm.style.display = 'none';
    overlay.style.display = 'none';
  });
});     

</script>

</body>
</html>
