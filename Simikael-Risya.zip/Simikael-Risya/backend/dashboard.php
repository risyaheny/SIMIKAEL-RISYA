<?php
include 'connect.php';
session_start();
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';

$allowed_roles = ['admin'];

if (!isset($_SESSION['id_user']) || !in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../login/sign-in-up.php");
    exit();
}


function getCount($conn, $table) {
  $query = "SELECT COUNT(*) AS total FROM $table";
  $result = mysqli_query($conn, $query);
  if ($result) {
      $row = mysqli_fetch_assoc($result);
      return $row['total'];
  } else {
      return 0;
  }
}

// Ambil jumlah data
$jumlahGuru = getCount($conn, 'guru');
$jumlahSiswa = getCount($conn, 'siswa');
$jumlahPengajuan = getCount($conn, 'ajuan_pkl');
$jumlahIndustri = getCount($conn, 'industri');
$jumlahUser= getCount($conn, 'user');
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
      .cards-container {
          display: flex;
          justify-content: space-between;
          flex-wrap: wrap;
          margin-top: 20px;
      }
      .card {
          flex: 1 1 200px;
          margin: 10px;
          padding: 20px;
          background-color: #f7f7f7;
          border-radius: 15px;
          text-align: center;
          box-shadow: 0 4px 8px rgba(0,0,0,0.1);
          transition: transform 0.3s;
      }
      .card:hover {
          transform: translateY(-10px);
      }
      .card i {
          font-size: 50px;
          margin-bottom: 10px;
          color: #35526f;
      }
      .card h3 {
          margin: 10px 0;
          font-size: 24px;
          color: #333;
      }
      .card p {
          font-size: 18px;
          color: #666;
      }
  </style>
</head>
<body>

<div class="sidebar">
  <div class="brand">𝕊𝕀𝕄𝕀𝕂✮𝔼𝕃</div>
  <a class="active" href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
  <a href="pengajuan/pengajuan.php"><i class="fa-solid fa-file-alt"></i>Pengajuan</a>
  <a href="industri/industri.php"><i class="fa-solid fa-industry"></i> Industri</a>
  <a href="siswa/siswa.php"><i class="fa-solid fa-user-graduate"></i> Siswa</a>
  <a href="guru/guru.php"><i class="fa-solid fa-chalkboard-user"></i> Guru</a>
  <a href="user/user.php"><i class="fa-solid fa-users"></i> Users</a>
  <a class="logout" href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
  <h1>Dashboard</h1><br>
  <p class="greeting">Hallo, <?= htmlspecialchars($username) ?>  ٩(^ᗜ^ )و ´-</p>
  <p>Anda login sebagai: <strong><?php echo ucfirst($_SESSION['role']); ?></strong></p>
  <p>Today is <?= date('l, F j, Y') ?>.</p>

  <!-- Card Section -->
  <div class="cards-container">
      <div class="card">
          <i class="fa-solid fa-file-alt"></i>
          <h3><?= $jumlahPengajuan ?></h3>
          <p>Total Pengajuan</p>
        </div>
        <div class="card">
            <i class="fa-solid fa-industry"></i>
            <h3><?= $jumlahIndustri ?></h3>
            <p>Total Industri</p>
        </div>
        <div class="card">
            <i class="fa-solid fa-user-graduate"></i>
            <h3><?= $jumlahSiswa ?></h3>
            <p>Total Siswa</p>
        </div>
        <div class="card">
            <i class="fa-solid fa-chalkboard-user"></i>
            <h3><?= $jumlahGuru ?></h3>
            <p>Total Guru</p>
          </div>
        <div class="card">
            <i class="fa-solid fa-chalkboard-user"></i>
            <h3><?= $jumlahUser ?></h3>
            <p>Total User</p>
          </div>
  </div>
</div>
</body>
</html>