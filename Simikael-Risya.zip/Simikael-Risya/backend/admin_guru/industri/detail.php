<?php
include '../connect.php';

$id_industri = $_GET['id'] ?? null;

if (!$id_industri) {
    die("ID tidak ditemukan.");
}

$sql = "SELECT * FROM industri WHERE id_industri = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id_industri);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Data industri dengan Id $id_industri tidak ditemukan.");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Industri</title>
    <link rel="stylesheet" href="../css/detail.css">
</head>
<body>
    <div id="modal-overlay" class="modal-overlay"></div>

    <div id="modal-content" class="modal">
        <div class="modal-header">
            <h1>Detail Industri</h1>
            <span class="close-button">ᯓ★</span>
        </div>
        <div class="modal-body">
            <div class="siswa-details">
                <table class="siswa-table">
                    <tr>
                        <td>Id Industri</td>
                        <td><?php echo $row['id_industri']; ?></td>
                    </tr>
                    <tr>
                        <td>Nama Industri</td>
                        <td><?php echo $row['nama_industri']; ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?php echo $row['alamat']; ?></td>
                    </tr>
                    <tr>
                        <td>Kontak</td>
                        <td><?php echo $row['kontak']; ?></td>
                    </tr>
                </table>
                <div class="kembali-button">
                    <a href="industri.php"><i class="fas fa-arrow-left"></i> Back</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>