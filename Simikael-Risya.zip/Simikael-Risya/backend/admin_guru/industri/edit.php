<?php
include '../connect.php';

$id_industri = $_GET['id'] ?? null;

if (!$id_industri) {
    die("ID industri tidak ditemukan.");
}

$sql = "SELECT * FROM industri WHERE id_industri = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id_industri);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Data industri dengan ID $id_industri tidak ditemukan.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_industri = strip_tags($_POST['nama_industri']);
    $alamat = strip_tags($_POST['alamat']);
    $kontak = strip_tags($_POST['kontak']);

    $update_sql = "UPDATE industri SET nama_industri = ?, alamat = ?, kontak = ? WHERE id_industri = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssss", $nama_industri, $alamat, $kontak, $id_industri);

    if ($update_stmt->execute()) {
        echo "<script>alert('Data industri berhasil diupdate!'); window.location.href='industri.php';</script>";
    } else {
        echo "Error: " . $update_stmt->error;
    }
} else {
    echo "<script>alert('Semua field harus diisi!');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <form action="edit.php?id=<?php echo $id_industri; ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id_industri" value="<?php echo $row['id_industri']; ?>">

        <div class="form-row">
            <label for="nama_industri">Nama Industri</label>
            <input type="text" name="nama_industri" id="nama_industri" value="<?php echo $row['nama_industri']; ?>" required>
        </div>

        <div class="form-row">
            <label for="alamat">Alamat</label>
            <input type="text" name="alamat" id="alamat" value="<?php echo $row['alamat']; ?>" required>
        </div>

        <div class="form-row">
            <label for="kontak">Kontak</label>
            <input type="text" name="kontak" id="kontak" value="<?php echo $row['kontak']; ?>" required>
        </div>

        <div class="form-update">
            <button class="form-update" type="submit">Update</button>
            <a href="industri.php" class="close-popup">Kembali</a>
        </div>
    </form>
</body>
</html>
