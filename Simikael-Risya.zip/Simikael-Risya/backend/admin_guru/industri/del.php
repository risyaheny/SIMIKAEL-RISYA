<?php
include '../connect.php';

if (isset($_GET['id'])) {
    $id_industri = $_GET['id'];

    $delete_query = "DELETE FROM industri WHERE id_industri = $id_industri";

    if (mysqli_query($conn, $delete_query)) {
        header("Location: industri.php");
        exit();
    } else {
        echo "Gagal menghapus data produk: " . mysqli_error($conn);
    }
} else {
    echo "Id Industri tidak ditemukan!";
}
?>