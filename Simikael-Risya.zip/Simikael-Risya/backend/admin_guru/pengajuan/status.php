<?php
include '../connect.php';

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id_ajuan = mysqli_real_escape_string($conn, $_GET['id']);
    $status = mysqli_real_escape_string($conn, $_GET['status']);

    $sql = "UPDATE ajuan_pkl SET status = ? WHERE id_ajuan = ?";
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $status, $id_ajuan);
        
        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Status berhasil diupdate!'); window.location.href='pengajuan.php';</script>";
        } else {
            echo "Error: " . mysqli_stmt_error($stmt);
        }
        
        mysqli_stmt_close($stmt);
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>