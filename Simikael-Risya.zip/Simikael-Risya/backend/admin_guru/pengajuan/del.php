<?php
include '../connect.php';

if (isset($_GET['id'])) {
    $id_ajuan = $_GET['id'];

    $delete_query = "DELETE FROM ajuan_pkl WHERE id_ajuan = $id_ajuan";

    if (mysqli_query($conn, $delete_query)) {
        header("Location: hasil_pkl.php");
        exit();
    } else {
        echo "Gagal menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "Id tidak ditemukan!";
}
?>