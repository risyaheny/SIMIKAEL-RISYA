<?php
include '../connect.php';

$nip = $_GET['id'] ?? null;

if (!$nip) {
    die("ID guru tidak ditemukan.");
}

$sql = "SELECT * FROM guru WHERE nip = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nip);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Data guru dengan NIP $nip tidak ditemukan.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_guru = strip_tags($_POST['nama_guru']);
    $bidang = strip_tags($_POST['bidang']);

    $update_sql = "UPDATE guru SET nama_guru = ?, bidang = ? WHERE nip = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sss", $nama_guru, $bidang, $nip);

    if ($update_stmt->execute()) {
        echo "<script>alert('Data guru berhasil diupdate!'); window.location.href='guru.php';</script>";
    } else {
        echo "Error: " . $update_stmt->error;
    }
} else {
    echo "<script>alert('Semua field harus diisi!');</script>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <form action="edit.php?id=<?php echo $nip; ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="nip" value="<?php echo $row['nip']; ?>">

        <div class="form-row">
            <label for="nama_guru">Nama Guru</label>
            <input type="text" name="nama_guru" id="nama_guru" value="<?php echo $row['nama_guru']; ?>" required>
        </div>

        <div class="form-row">
            <label for="bidang">Bidang</label>
            <input type="text" name="bidang" id="bidang" value="<?php echo $row['bidang']; ?>" required>
        </div>

        <div class="form-update">
            <button class="form-update" type="submit">Update</button>
            <a href="guru.php" class="close-popup">Kembali</a>
        </div>
    </form>
</body>
</html>
