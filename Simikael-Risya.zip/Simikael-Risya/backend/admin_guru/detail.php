<?php
include '../connect.php';

$nip = $_GET['id'] ?? null;

if (!$nip) {
    die("ID guru tidak ditemukan.");
}

$sql = "SELECT * FROM guru WHERE nip = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nip);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Data guru dengan NIP $nip tidak ditemukan.");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Guru</title>
    <link rel="stylesheet" href="../css/detail.css">
</head>
<body>
    <div id="modal-overlay" class="modal-overlay"></div>

    <div id="modal-content" class="modal">
        <div class="modal-header">
            <h1>Detail Guru</h1>
            <span class="close-button">ᯓ★</span>
        </div>
        <div class="modal-body">
            <div class="siswa-details">
                <table class="siswa-table">
                    <tr>
                        <td>Id Guru</td>
                        <td><?php echo $row['id_guru']; ?></td>
                    </tr>
                    <tr>
                        <td>NIP Guru</td>
                        <td><?php echo $row['nip']; ?></td>
                    </tr>
                    <tr>
                        <td>Nama Guru</td>
                        <td><?php echo $row['nama_guru']; ?></td>
                    </tr>
                    <tr>
                        <td>Bidang</td>
                        <td><?php echo $row['bidang']; ?></td>
                    </tr>
                </table>
                <div class="kembali-button">
                    <a href="guru.php"><i class="fas fa-arrow-left"></i> Back</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>