<?php
$host = "localhost";
$user = "root"; 
$pass = "";
$db = "pengajuan_pkl";

$conn = new mysqli($host, $user, $pass, $db);

?>
