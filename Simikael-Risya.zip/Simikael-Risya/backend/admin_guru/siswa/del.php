<?php
include '../connect.php';

if (isset($_GET['id'])) {
    $id_siswa = $_GET['id'];

    $delete_query = "DELETE FROM siswa WHERE id_siswa = $id_siswa";

    if (mysqli_query($conn, $delete_query)) {
        header("Location: siswa.php");
        exit();
    } else {
        echo "Gagal menghapus data produk: " . mysqli_error($conn);
    }
} else {
    echo "Id Industri tidak ditemukan!";
}
?>