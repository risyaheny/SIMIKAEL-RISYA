<?php
include '../connect.php';

$id_siswa = $_GET['id'] ?? null;

if (!$id_siswa) {
    die("ID tidak ditemukan.");
}

$sql = "SELECT * FROM siswa WHERE id_siswa = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id_siswa);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Data siswa dengan ID $id_siswa tidak ditemukan.");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Siswa</title>
    <link rel="stylesheet" href="../css/detail.css">
</head>
<body>
    <div id="modal-overlay" class="modal-overlay"></div>

    <div id="modal-content" class="modal">
        <div class="modal-header">
            <h1>Detail Siswa</h1>
            <span class="close-button">ᯓ★</span>
        </div>
        <div class="modal-body">
            <div class="siswa-details">
                <table class="siswa-table">
                    <tr>
                        <td>ID Siswa</td>
                        <td><?php echo $row['id_siswa']; ?></td>
                    </tr>
                    <tr>
                        <td>Nama Siswa</td>
                        <td><?php echo $row['nama_siswa']; ?></td>
                    </tr>
                    <tr>
                        <td>NIS</td>
                        <td><?php echo $row['nis']; ?></td>
                    </tr>
                    <tr>
                        <td>Kelas</td>
                        <td><?php echo $row['kelas']; ?></td>
                    </tr>
                    <tr>
                        <td>Jurusan</td>
                        <td><?php echo $row['jurusan']; ?></td>
                    </tr>
                    <tr>
                        <td>ID User</td>
                        <td><?php echo $row['id_user']; ?></td>
                    </tr>
                </table>
                <div class="kembali-button">
                    <a href="siswa.php"><i class="fas fa-arrow-left"></i> Back</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>