<?php
include '../connect.php';

$id_siswa = $_GET['id'] ?? null;

if (!$id_siswa) {
    die("ID siswa tidak ditemukan.");
}

$sql = "SELECT * FROM siswa WHERE id_siswa = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id_siswa);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Data siswa dengan ID $id_siswa tidak ditemukan.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_siswa = strip_tags($_POST['nama_siswa']);
    $nis = strip_tags($_POST['nis']);
    $kelas = strip_tags($_POST['kelas']);
    $jurusan = strip_tags($_POST['jurusan']);
    $id_user = strip_tags($_POST['id_user']);

    $update_sql = "UPDATE siswa SET nama_siswa = ?, nis = ?, kelas = ?, jurusan = ?, id_user = ? WHERE id_siswa = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssssss", $nama_siswa, $nis, $kelas, $jurusan, $id_user, $id_siswa);

    if ($update_stmt->execute()) {
        echo "<script>alert('Data siswa berhasil diupdate!'); window.location.href='siswa.php';</script>";
    } else {
        echo "Error: " . $update_stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <form action="edit.php?id=<?php echo $id_siswa; ?>" method="POST">
        <input type="hidden" name="id_siswa" value="<?php echo $row['id_siswa']; ?>">

        <div class="form-row">
            <label for="nama_siswa">Nama Siswa</label>
            <input type="text" name="nama_siswa" id="nama_siswa" value="<?php echo $row['nama_siswa']; ?>" required>
        </div>

        <div class="form-row">
            <label for="nis">NIS</label>
            <input type="text" name="nis" id="nis" value="<?php echo $row['nis']; ?>" required>
        </div>

        <div class="form-row">
            <label for="kelas">Kelas</label>
            <input type="text" name="kelas" id="kelas" value="<?php echo $row['kelas']; ?>" required>
        </div>

        <div class="form-row">
            <label for="jurusan">Jurusan</label>
            <input type="text" name="jurusan" id="jurusan" value="<?php echo $row['jurusan']; ?>" required>
        </div>

        <div class="form-row">
            <label for="id_user">ID User</label>
            <input type="text" name="id_user" id="id_user" value="<?php echo $row['id_user']; ?>" required>
        </div>

        <div class="form-update">
            <button class="form-update" type="submit">Update</button>
            <a href="siswa.php" class="close-popup">Kembali</a>
        </div>
    </form>
</body>
</html>