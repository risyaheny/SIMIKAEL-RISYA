<?php
include '../connect.php';

if (isset($_GET['id'])) {
    $nip = $_GET['id'];

    $delete_query = "DELETE FROM guru WHERE nip = '$nip'";

    if (mysqli_query($conn, $delete_query)) {
        header("Location: guru.php");
        exit();
    } else {
        echo "Gagal menghapus data produk: " . mysqli_error($conn);
    }
} else {
    echo "NIS produk tidak ditemukan!";
}
?>