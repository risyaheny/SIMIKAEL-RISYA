<?php
include '../connect.php';

if (isset($_GET['id'])) {
    $id_user = $_GET['id'];

    $delete_query = "DELETE FROM user WHERE id_user = '$id_user'";

    if (mysqli_query($conn, $delete_query)) {
        header("Location: user.php");
        exit();
    } else {
        echo "Gagal menghapus data produk: " . mysqli_error($db);
    }
} else {
    echo "ID produk tidak ditemukan!";
}
?>
