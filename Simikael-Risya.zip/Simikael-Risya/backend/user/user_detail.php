<?php
include '../connect.php';
$query = "SELECT * FROM user";
$result = mysqli_query($conn, $query);

$id_user = $_GET['id'] ?? null;

if ($id_user) {
    $query = "SELECT * FROM user WHERE id_user = '$id_user'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        $row = null;
    }
} else {
    echo "ID produk tidak diberikan.";
    exit;
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Siswa</title>
    <link rel="stylesheet" href="../css/detail.css">
</head>
<body>
    <div id="modal-overlay" class="modal-overlay"></div>

    <div id="modal-content" class="modal">
        <div class="modal-header">
            <h1>Detail Siswa</h1>
            <span class="close-button">ᯓ★</span>
        </div>
        <div class="modal-body">
            <div class="siswa-details">
                <table class="siswa-table">
                    <tr>
                        <td>ID User</td>
                        <td><?php echo $row['id_user']; ?></td>
                    </tr>
                    <tr>
                        <td>Nama User</td>
                        <td><?php echo $row['username']; ?></td>
                    </tr>
                    <tr>
                        <td>Role</td>
                        <td><?php echo $row['role']; ?></td>
                    </tr>
                </table>
                <div class="kembali-button">
                    <a href="user.php"><i class="fas fa-arrow-left"></i> Back</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>