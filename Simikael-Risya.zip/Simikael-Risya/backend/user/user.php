<?php
include '../connect.php';
session_start();

$allowed_roles = ['admin'];

if (!isset($_SESSION['id_user']) || !in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../../login/sign-in-up.php"); 
    exit();
}
function uploadUserData($data) {
    global $conn;
    if (empty($data['password']) || empty($data['username']) || empty($data['role'])) {
        return -1; 
    }

    $password = password_hash($data['password'], PASSWORD_DEFAULT);
    $username = mysqli_real_escape_string($conn, $data['username']);
    $role = mysqli_real_escape_string($conn, $data['role']);

    $query = "INSERT INTO user (password, username, role) 
              VALUES ('$password', '$username', '$role')";

    if (mysqli_query($conn, $query)) {
        return 1; 
    } else {
        return 0;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_user') {
    $result = uploadUserData($_POST);
    if ($result > 0) {
        echo "<script>alert('User berhasil ditambahkan!'); window.location.href='user.php';</script>";
    } elseif ($result === -1) {
        echo "<script>alert('Data user tidak lengkap!'); window.location.href='user.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan user: " . mysqli_error($conn) . "'); window.location.href='user.php';</script>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'update_user') {
    $id_user = mysqli_real_escape_string($conn, $_POST['id_user']);
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    if (!empty($id_user) && !empty($username) && !empty($role)) {
        $update_query = "UPDATE user SET username = '$username', role = '$role'";
        if ($password) {
            $update_query .= ", password = '$password'";
        }
        $update_query .= " WHERE id_user = '$id_user'";

        if (mysqli_query($conn, $update_query)) {
            echo "<script>alert('Data user berhasil diupdate!'); window.location.href='user.php';</script>";
        } else {
            echo "<script>alert('Gagal mengupdate data user: " . mysqli_error($conn) . "'); window.location.href='user.php';</script>";
        }
    } else {
        echo "<script>alert('Semua field harus diisi!');</script>";
    }
}

$query = "SELECT id_user, password, username, role FROM user";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="sidebar">
  <div class="brand">𝕊𝕀𝕄𝕀𝕂✮𝔼𝕃</div>
  <a class="active" href="../dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
  <a href="../pengajuan/pengajuan.php"><i class="fa-solid fa-file-alt"></i>Pengajuan</a>
  <a href="../industri/industri.php"><i class="fa-solid fa-industry"></i> Industri</a>
  <a href="../siswa/siswa.php"><i class="fa-solid fa-user-graduate"></i> Siswa</a>
  <a href="../guru/guru.php"><i class="fa-solid fa-chalkboard-user"></i></i> Guru</a>
  <a href="../user/user.php"><i class="fa-solid fa-users"></i> Users</a>
  <a class="logout" href="../../login/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>
<div class="content">
  <h1>User</h1>
  <p>Anda bisa mengontrol User melalui ini.</p>
  <button class="btn add" id="add-btn">Tambah</button>
</div>
        <table id="data-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID User</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $row['id_user'] ?></td>
                        <td><?= $row['username'] ?></td>
                        <td><?= $row['role'] ?></td>
                        <td>
                            <a style="text-decoration:none" href="user_detail.php?id=<?= $row['id_user'] ?>" class="btn btn-detail">Detail</a>
                            <a href="#" class="btn btn-edit" data-id="<?= $row['id_user'] ?>">Edit</a>
                            <a style="text-decoration:none" href="user_del.php?id=<?= $row['id_user'] ?>" class="btn btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">Delete</a>                            
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <div id="overlay"></div>
    <div id="form-container">
    <form action="user.php" method="POST">
        <input type="hidden" name="action" value="add_user">
        <label for="username">Username</label>
        <input type="text" name="username" id="username" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <label for="role">Role</label>
        <select name="role" id="role" required>
            <option value="siswa">Siswa</option>
            <option value="admin">Admin</option>
            <option value="guru">Guru</option>
        </select>

        <button type="submit">Tambah User</button>
        <a href="user.php" id="kembali" class="close-popup">Kembali</a>
    </form>

    </div>

    <div id="overlay"></div>
    <div class="edit-form"></div> 
    <div id="form-container">
        <form action="user_edit.php?id=<?php echo $row['id_user']; ?>" method="POST">
            <input type="hidden" name="action" value="add_user">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required><br>

            <label for="password">Password</label>
            <input type="password" name="password" id="password" required><br>

            <label for="role">Role</label>
            <select name="role" id="role" required>
                <option value="siswa">Siswa</option>
                <option value="admin">Admin</option>
                <option value="guru">Guru</option>
            </select><br>

            <button type="submit">Update</button>
            <a href="user.php" id="kembali" class="close-popup">Kembali</a>
        </form>
    </div>

    <script>
        const overlay = document.getElementById('overlay');
        const addForm = document.getElementById('form-container');
        const editForm = document.querySelector('.edit-form');
        const addBtn = document.getElementById('add-btn');
        const closeAddBtn = addForm.querySelector('.close-popup');
        const editButtons = document.querySelectorAll('.btn-edit');

        addBtn.addEventListener('click', () => {
            overlay.style.display = 'block';
            addForm.style.display = 'block';
        });

        closeAddBtn.addEventListener('click', () => {
            overlay.style.display = 'none';
            addForm.style.display = 'none';
        });

        overlay.addEventListener('click', (event) => {
            if (event.target === overlay) {
                overlay.style.display = 'none';
                addForm.style.display = 'none';
                editForm.style.display = 'none';
            }
        });

        // edit
        document.addEventListener('DOMContentLoaded', () => {
    const editForm = document.querySelector('.edit-form');
    const overlay = document.getElementById('overlay');
    const editButtons = document.querySelectorAll('.btn-edit');
    const closePopupButton = document.querySelector('.edit-form .close-popup');

  editButtons.forEach(button => {
  button.addEventListener('click', (event) => {
  event.preventDefault();
  const productId = button.getAttribute('data-id');

  // Lakukan AJAX untuk mengambil data produk berdasarkan ID (opsional)
  fetch(`user_edit.php?id=${productId}`)
  .then(response => response.text())
  .then(html => {
    // Tampilkan form edit dengan data produk
    editForm.innerHTML = html;
    editForm.style.display = 'block';
    overlay.style.display = 'block';
        });
    });
});

closePopupButton.addEventListener('click', () => {
    editForm.style.display = 'none';
    overlay.style.display = 'none';
  });

overlay.addEventListener('click', () => {
    editForm.style.display = 'none';
    overlay.style.display = 'none';
  });
});

document.getElementById("kembali").style.display = "none";
    </script>
</body>
</html>