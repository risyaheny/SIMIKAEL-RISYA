<?php
include '../connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user    = $_POST['id_user'];
    $username   = $_POST['username'];
    $namauser   = $_POST['namauser'];
    $emailuser  = $_POST['emailuser'];
    $role       = $_POST['role'];

    // Handle password update only if a new password is provided
    $password_update = "";
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $password_update = ", password = '$password'";
    }

    // Gunakan Prepared Statements untuk mencegah SQL Injection
    $query = $conn->prepare("UPDATE user SET username = ?, namauser = ?, emailuser = ?, role = ? $password_update WHERE id_user = ?");
    $query->bind_param("ssssi", $username, $namauser, $emailuser, $role, $id_user);

    if ($query->execute()) {
        echo "<script>alert('Data berhasil diperbarui!'); window.location.href='user.php';</script>";
        exit;
    } else {
        echo "Error: " . $query->error;
    }
    $query->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id_user = $_GET['id'];

    // Gunakan Prepared Statements untuk mencegah SQL Injection
    $query = $conn->prepare("SELECT * FROM user WHERE id_user = ?");
    $query->bind_param("i", $id_user);
    $query->execute();
    $result = $query->get_result();
    $row = $result->fetch_assoc();
    $query->close();

    if ($row) { // Pastikan data user ditemukan
        echo "
        <form action='user_edit.php?id={$row['id_user']}' method='POST'>
            <input type='hidden' name='id_user' value='{$row['id_user']}'>
            
            <label for='username'>Username</label>
            <input type='text' name='username' id='username' value='{$row['username']}' required>

            <label for='password'>Password (kosongkan jika tidak ingin diubah)</label>
            <input type='password' name='password' id='password'>

            <label for='role'>Role</label>
            <select name='role' id='role' required>
                <option value='user' " . ($row['role'] == 'siswa' ? 'selected' : '') . ">Siswa</option>
                <option value='admin' " . ($row['role'] == 'admin' ? 'selected' : '') . ">Admin</option>
                <option value='admin' " . ($row['role'] == 'guru' ? 'selected' : '') . ">Guru</option>
            </select>

            <button type='submit'>Update</button>
            <a href='user.php' class='close-popup'>Kembali</a>
        </form>";
    } else {
        echo "User tidak ditemukan.";
    }
    exit;
}
?>
