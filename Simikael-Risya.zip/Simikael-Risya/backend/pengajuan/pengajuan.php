<?php
include '../connect.php'; 
session_start();

$allowed_roles = ['admin'];

if (!isset($_SESSION['id_user']) || !in_array($_SESSION['role'], $allowed_roles)) {
  header("Location: ../../login/sign-in-up.php"); 
  exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $tanggal_mulai = mysqli_real_escape_string($conn, $_POST['tanggal_mulai']);
  $id_siswa = mysqli_real_escape_string($conn, $_POST['id_siswa']);
  $tanggal_selesai = mysqli_real_escape_string($conn, $_POST['tanggal_selesai']);
  $id_industri = mysqli_real_escape_string($conn, $_POST['id_industri']);
  $tanggal_pengajuan = mysqli_real_escape_string($conn, $_POST['tanggal_pengajuan']);

  $id_ajuan = uniqid('ajuan_pkl');
  $status = 'pending'; 

  $sql = "INSERT INTO ajuan_pkl (id_ajuan, tanggal_mulai, id_siswa, tanggal_selesai, id_industri, tanggal_pengajuan, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)";


  if (empty($tanggal_mulai) || empty($id_siswa) || empty($tanggal_selesai) || empty($id_industri)) {
      echo "Error: Semua field harus diisi.";
      exit; 
  }

  $sql = "INSERT INTO ajuan_pkl (id_ajuan, tanggal_mulai, id_siswa, tanggal_selesai, id_industri, tanggal_pengajuan)
          VALUES (?, ?, ?, ?, ?, ?)";

  $stmt = mysqli_prepare($conn, $sql);
  if ($stmt) {
      mysqli_stmt_bind_param($stmt, "ssssss", $id_ajuan, $tanggal_mulai, $id_siswa, $tanggal_selesai, $id_industri, $tanggal_pengajuan);

      if (mysqli_stmt_execute($stmt)) {
          echo "<script>alert('Data berhasil disimpan!'); window.location.href='daftar.php';</script>";
          exit;
      } else {
          echo "Error: " . mysqli_stmt_error($stmt);
      }

      mysqli_stmt_close($stmt);
  } else {
      echo "Error: " . mysqli_error($conn);
  }

  mysqli_close($conn);
}

$query = "SELECT * FROM ajuan_pkl";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">
</head>
<style>
    table{
    }
</style>
<body>

<div class="sidebar">
  <div class="brand">𝕊𝕀𝕄𝕀𝕂✮𝔼𝕃</div>
  <a class="active" href="../dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
  <a href="../pengajuan/pengajuan.php"><i class="fa-solid fa-file-alt"></i>Pengajuan</a>
  <a href="../industri/industri.php"><i class="fa-solid fa-industry"></i> Industri</a>
  <a href="../siswa/siswa.php"><i class="fa-solid fa-user-graduate"></i> Siswa</a>
  <a href="../guru/guru.php"><i class="fa-solid fa-chalkboard-user"></i> Guru</a>
  <a href="../user/user.php"><i class="fa-solid fa-users"></i> Users</a>
  <a class="logout" href="../../login/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
  <h1>Pengajuan</h1>
  <p>Anda bisa mengajukan data pengajuan di sini.</p>
  <a href="../../export_pdf/pdf_pkl.php" class="btn export1">Export PDF</a>
</div>

<div id="overlay"></div>
<div id="form-container">
  <form action="pengajuan.php" method="POST" enctype="multipart/form-data">
    <div class="form-row">
        <input type="hidden" name="id_ajuan" value="<?php echo uniqid('ajuan_pkl'); ?>">
    </div>

    <div class="form-row">
        <label for="id_siswa">ID Siswa</label>
        <input type="number" name="id_siswa" id="id_siswa" required>
    </div>

    <div class="form-row">
        <label for="id_industri">ID Industri</label>
        <input type="number" name="id_industri" id="id_industri" required>
    </div>

    <div class="form-row">
        <label for="tanggal_mulai">Tanggal Mulai</label>
        <input type="date" name="tanggal_mulai" id="tanggal_mulai" required>
    </div>

    <div class="form-row">
        <label for="tanggal_selesai">Tanggal Selesai</label>
        <input type="date" name="tanggal_selesai" id="tanggal_selesai" required>
    </div>

    <div class="form-row">
        <label for="tanggal_pengajuan">Tanggal Pengajuan</label>
        <input type="date" id="tanggal_pengajuan" name="tanggal_pengajuan" readonly>
    </div>

    <div class="form-row">
        <label for="status">Status</label>
        <input type="text" name="status" id="status" required>
    </div>

    <div class="form-actions">
        <button type="submit">Kirim Pengajuan</button>
        <button type="button" class="close-popup" id="close-btn">Close</button>
    </div>
  </form>
</div>

<table id="data-table">
  <thead>
    <tr>
      <th>No</th>
      <th>ID Ajuan</th>
      <th>ID Siswa</th>
      <th>ID Industri</th>
      <th>Tgl Mulai</th>
      <th>Tgl Selesai</th>
      <th>Tgl Pengajuan</th>
      <th>Status</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
      ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['id_ajuan'] ?></td>
        <td><?= $row['id_siswa'] ?></td>
        <td><?= $row['id_industri'] ?></td>
        <td><?= $row['tanggal_mulai'] ?></td>
        <td><?= $row['tanggal_selesai'] ?></td>
        <td><?= $row['tanggal_pengajuan'] ?></td>
        <td><?= $row['status'] ?></td>
        <td>
            <a href="status.php?id=<?= $row['id_ajuan'] ?>&status=disetujui" class="btn btn-success" onclick="return confirm('Setujui pengajuan ini?')">Setujui</a>
            <a href="status.php?id=<?= $row['id_ajuan'] ?>&status=ditolak" class="btn btn-danger" onclick="return confirm('Tolak pengajuan ini?')">Tolak</a>
          <a style="text-decoration:none" href="del.php?id=<?= $row['id_ajuan'] ?>" class="btn btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">Delete</a>
        </td>
      </tr>
    <?php } ?>
  </tbody>
</table>

<script>
//   POPUP ADD
const addBtn = document.getElementById('add-btn');
const formContainer = document.getElementById('form-container');
const overlay = document.getElementById('overlay');
const closeBtn = document.getElementById('close-btn');

addBtn.addEventListener('click', function() {
    formContainer.style.display = 'block';
    overlay.style.display = 'block';
});

closeBtn.addEventListener('click', function() {
    formContainer.style.display = 'none';
    overlay.style.display = 'none';
});

overlay.addEventListener('click', function() {
    formContainer.style.display = 'none';
    overlay.style.display = 'none';
});

document.addEventListener('DOMContentLoaded', () => {
    const editForm = document.querySelector('.edit-form');
    const overlay = document.getElementById('overlay');
    const editButtons = document.querySelectorAll('.btn-edit');
    const closePopupButton = document.querySelector('.edit-form .close-popup');

  editButtons.forEach(button => {
  button.addEventListener('click', (event) => {
  event.preventDefault();
  const productId = button.getAttribute('data-id');

  fetch(`?id=${productId}`)
  .then(response => response.text())
  .then(html => {
    editForm.innerHTML = html;
    editForm.style.display = 'block';
    overlay.style.display = 'block';
        });
    });
});

closeBtn.style.display = 'none';

closePopupButton.addEventListener('click', () => {
    editForm.style.display = 'none';
    overlay.style.display = 'none';
  });

overlay.addEventListener('click', () => {
    editForm.style.display = 'none';
    overlay.style.display = 'none';
  });
});
</script>

</body>
</html>
