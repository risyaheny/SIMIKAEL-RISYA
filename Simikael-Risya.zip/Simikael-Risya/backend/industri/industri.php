<?php
include '../connect.php';
session_start();

$allowed_roles = ['admin'];

if (!isset($_SESSION['id_user']) || !in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../../login/sign-in-up.php"); 
  exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_industri'])) {
    $id_industri = isset($_POST['id_industri']) ? trim($_POST['id_industri']) : '';
    $nama_industri = isset($_POST['nama_industri']) ? trim($_POST['nama_industri']) : '';
    $alamat = isset($_POST['alamat']) ? trim($_POST['alamat']) : '';
    $kontak = isset($_POST['kontak']) ? trim($_POST['kontak']) : '';
    
    if ($id_industri && $nama_industri && $alamat && $kontak) {
        $stmt = $conn->prepare("INSERT INTO industri (id_industri, nama_industri, alamat, kontak) 
                                VALUES (?, ?, ?, ?) 
                                ON DUPLICATE KEY UPDATE 
                                nama_industri = VALUES(nama_industri), 
                                alamat = VALUES(alamat), 
                                kontak = VALUES(kontak)");
        
        $stmt->bind_param("ssss", $id_industri, $nama_industri, $alamat, $kontak);
        
        if ($stmt->execute()) {
            echo "<script>alert('Data industri berhasil ditambahkan!');</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Data tidak lengkap!";
    }
}

$query = "SELECT * FROM industri";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="sidebar">
  <div class="brand">𝕊𝕀𝕄𝕀𝕂✮𝔼𝕃</div>
  <a class="active" href="../dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
  <a href="../pengajuan/pengajuan.php"><i class="fa-solid fa-file-alt"></i>Pengajuan</a>
  <a href="../industri/industri.php"><i class="fa-solid fa-industry"></i> Industri</a>
  <a href="../siswa/siswa.php"><i class="fa-solid fa-user-graduate"></i> Siswa</a>
  <a href="../guru/guru.php"><i class="fa-solid fa-chalkboard-user"></i></i> Guru</a>
  <a href="../user/user.php"><i class="fa-solid fa-users"></i> Users</a>
  <a class="logout" href="../../login/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
    <h1>Industri</h1>
    <p>Anda bisa mengontrol data industri melalui ini.</p>
    <button class="btn add" id="add-btn">Tambah</button>
    <a href="../../export_pdf/pdf_industri.php" class="btn export">Export PDF</a>
</div>

<div id="overlay"></div>
<div id="form-container">
    <form action="industri.php" method="POST">
        <div class="form-row">
            <label for="id_industri">Id</label>
            <input type="number" name="id_industri" id="id_industri" required>
        </div>
        
        <div class="form-row">
            <label for="nama_industri">Nama Industri</label>
            <input type="text" name="nama_industri" id="nama_industri" required>
        </div>
        
        <div class="form-row">
            <label for="alamat">Alamat</label>
            <input type="text" name="alamat" id="alamat" required>
        </div>    
        
        <div class="form-row">
            <label for="kontak">Kontak</label>
            <input type="text" name="kontak" id="kontak" required>
        </div>
        
        <div class="form-actions">
            <button type="submit">Upload Data</button>
            <button type="button" class="close-popup" id="close-btn">Close</button>
        </div>
    </form>
</div>

<table id="data-table">
    <thead>
        <tr>
            <th>No</th>
            <th>Id</th>
            <th>Nama Industri</th>
            <th>Alamat</th>
            <th>Kontak</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['id_industri'] ?></td>
            <td><?= $row['nama_industri'] ?></td>
            <td><?= $row['alamat'] ?></td>
            <td><?= $row['kontak'] ?></td>
            <td>
                <a href="detail.php?id=<?= $row['id_industri'] ?>" class="btn btn-detail">Detail</a>
                <a href="#" class="btn btn-edit" data-id="<?= $row['id_industri'] ?>">Edit</a>
                <a href="del.php?id=<?= $row['id_industri'] ?>" class="btn btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

<!-- edit -->
<div id="overlay"></div>
<div class="edit-form">
<h1 style="color: red;">Edit Form</h1>
    <form action="guru_edit.php?id=<?php echo $row['id_industri']; ?>" method="POST">
    <label for="id_industri">Id Industri</label>
        <input type="number" name="id_industri" id="id_industri" required>

        <label for="nama_industri">Nama Industri</label>
        <input type="text" name="nama_industri" id="nama_industri" required>

        <label for="kontak">Kontak</label>
        <input type="text" name="kontak" id="kontak" required>

        <button type="submit">Update Data</button>
        <a href="guru.php" class="close-popup">Kembali</a>
    </form>
</div>

<script>
// POPUP ADD
const addBtn = document.getElementById('add-btn');
const formContainer = document.getElementById('form-container');
const overlay = document.getElementById('overlay');
const closeBtn = document.getElementById('close-btn');

addBtn.addEventListener('click', function() {
    formContainer.style.display = 'block';
    overlay.style.display = 'block';
});

closeBtn.addEventListener('click', function() {
    formContainer.style.display = 'none';
    overlay.style.display = 'none';
});

overlay.addEventListener('click', function() {
    formContainer.style.display = 'none';
    overlay.style.display = 'none';
});

document.addEventListener('DOMContentLoaded', () => {
    const editForm = document.querySelector('.edit-form');
    const overlay = document.getElementById('overlay');
    const editButtons = document.querySelectorAll('.btn-edit');
    const closePopupButton = document.querySelector('.edit-form .close-popup');

  editButtons.forEach(button => {
  button.addEventListener('click', (event) => {
  event.preventDefault();
  const productId = button.getAttribute('data-id');

  fetch(`edit.php?id=${productId}`)
  .then(response => response.text())
  .then(html => {
    editForm.innerHTML = html;
    editForm.style.display = 'block';
    overlay.style.display = 'block';
        });
    });
});

closeBtn.style.display = 'none';

closePopupButton.addEventListener('click', () => {
    editForm.style.display = 'none';
    overlay.style.display = 'none';
  });

overlay.addEventListener('click', () => {
    editForm.style.display = 'none';
    overlay.style.display = 'none';
  });
});     

</script>

</body>
</html>