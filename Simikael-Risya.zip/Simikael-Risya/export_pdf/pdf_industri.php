<?php
require('../fpdf.php');
include '../backend/connect.php';

$query = "SELECT * FROM industri";
$result = mysqli_query($conn, $query);

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

$pdf->Cell(0, 10, 'Data Industri', 0, 1, 'C');
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 10, 'No', 1, 0, 'C');
$pdf->Cell(30, 10, 'ID Industri', 1, 0, 'C');
$pdf->Cell(50, 10, 'Nama Industri', 1, 0, 'C');
$pdf->Cell(60, 10, 'Alamat', 1, 0, 'C');
$pdf->Cell(40, 10, 'Kontak', 1, 1, 'C');

$pdf->SetFont('Arial', '', 10);
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    $pdf->Cell(10, 10, $no++, 1, 0, 'C');
    $pdf->Cell(30, 10, $row['id_industri'], 1, 0, 'C');
    $pdf->Cell(50, 10, $row['nama_industri'], 1, 0, 'C');
    $pdf->Cell(60, 10, $row['alamat'], 1, 0, 'C');
    $pdf->Cell(40, 10, $row['kontak'], 1, 1, 'C');
}

$pdf->Output('D', 'Data_Industri.pdf');

mysqli_close($conn);
?>
