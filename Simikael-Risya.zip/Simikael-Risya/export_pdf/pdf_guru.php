<?php
require('../fpdf.php');
include '../backend/connect.php';

// Ambil data dari tabel guru
$query = "SELECT * FROM guru";
$result = mysqli_query($conn, $query);

// Inisialisasi FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

// Header PDF
$pdf->Cell(0, 10, 'Data Guru', 0, 1, 'C');
$pdf->Ln(10);

// Header tabel
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 10, 'No', 1, 0, 'C');
$pdf->Cell(30, 10, 'ID Guru', 1, 0, 'C');
$pdf->Cell(50, 10, 'Nama Guru', 1, 0, 'C');
$pdf->Cell(40, 10, 'NIP', 1, 0, 'C');
$pdf->Cell(60, 10, 'Bidang', 1, 1, 'C');

// Isi tabel
$pdf->SetFont('Arial', '', 10);
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    $pdf->Cell(10, 10, $no++, 1, 0, 'C');
    $pdf->Cell(30, 10, $row['id_guru'], 1, 0, 'C');
    $pdf->Cell(50, 10, $row['nama_guru'], 1, 0, 'C');
    $pdf->Cell(40, 10, $row['nip'], 1, 0, 'C');
    $pdf->Cell(60, 10, $row['bidang'], 1, 1, 'C');
}

$pdf->Output('D', 'Data_Guru.pdf');

mysqli_close($conn);
?>