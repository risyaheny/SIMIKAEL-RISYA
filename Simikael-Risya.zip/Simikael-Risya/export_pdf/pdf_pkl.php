<?php
require('../fpdf.php');
include '../backend/connect.php';

// Ambil data dari tabel ajuan_pkl
$query = "SELECT * FROM ajuan_pkl";
$result = mysqli_query($conn, $query);

// Inisialisasi FPDF dengan orientasi landscape
$pdf = new FPDF('L', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);

// Header PDF
$pdf->Cell(0, 10, 'Data Ajuan PKL', 0, 1, 'C');
$pdf->Ln(5);

// Header tabel
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 12, 'No', 1, 0, 'C');
$pdf->Cell(25, 12, 'ID Ajuan', 1, 0, 'C');
$pdf->Cell(25, 12, 'ID Siswa', 1, 0, 'C');
$pdf->Cell(25, 12, 'ID Industri', 1, 0, 'C');
$pdf->Cell(40, 12, 'Tanggal Mulai', 1, 0, 'C');
$pdf->Cell(40, 12, 'Tanggal Selesai', 1, 0, 'C');
$pdf->Cell(50, 12, 'Tanggal Pengajuan', 1, 0, 'C');
$pdf->Cell(40, 12, 'Status', 1, 1, 'C');

// Isi tabel
$pdf->SetFont('Arial', '', 10);
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    $pdf->Cell(10, 12, $no++, 1, 0, 'C');
    $pdf->Cell(25, 12, $row['id_ajuan'], 1, 0, 'C');
    $pdf->Cell(25, 12, $row['id_siswa'], 1, 0, 'C');
    $pdf->Cell(25, 12, $row['id_industri'], 1, 0, 'C');
    $pdf->Cell(40, 12, $row['tanggal_mulai'], 1, 0, 'C');
    $pdf->Cell(40, 12, $row['tanggal_selesai'], 1, 0, 'C');
    $pdf->Cell(50, 12, $row['tanggal_pengajuan'], 1, 0, 'C');
    $pdf->Cell(40, 12, $row['status'], 1, 1, 'C');
}

$pdf->Output('D', 'Data_Ajuan_PKL.pdf');

mysqli_close($conn);
?>