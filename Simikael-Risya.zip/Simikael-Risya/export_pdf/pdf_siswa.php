<?php
require('../fpdf.php');
include '../backend/connect.php';

$query = "SELECT * FROM siswa";
$result = mysqli_query($conn, $query);

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

$pdf->Cell(0, 10, 'Data Siswa', 0, 1, 'C');
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 10, 'No', 1, 0, 'C');
$pdf->Cell(20, 10, 'ID Siswa', 1, 0, 'C');
$pdf->Cell(40, 10, 'Nama Siswa', 1, 0, 'C');
$pdf->Cell(25, 10, 'NIS', 1, 0, 'C');
$pdf->Cell(20, 10, 'Kelas', 1, 0, 'C');
$pdf->Cell(40, 10, 'Jurusan', 1, 0, 'C');
$pdf->Cell(25, 10, 'ID User', 1, 1, 'C');

$pdf->SetFont('Arial', '', 10);
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    $pdf->Cell(10, 10, $no++, 1, 0, 'C');
    $pdf->Cell(20, 10, $row['id_siswa'], 1, 0, 'C');
    $pdf->Cell(40, 10, $row['nama_siswa'], 1, 0, 'C');
    $pdf->Cell(25, 10, $row['nis'], 1, 0, 'C');
    $pdf->Cell(20, 10, $row['kelas'], 1, 0, 'C');
    $pdf->Cell(40, 10, $row['jurusan'], 1, 0, 'C');
    $pdf->Cell(25, 10, $row['id_user'], 1, 1, 'C');
}

$pdf->Output('D', 'Data_Siswa.pdf');

mysqli_close($conn);
?>