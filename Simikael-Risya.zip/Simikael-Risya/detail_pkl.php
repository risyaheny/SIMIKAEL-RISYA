<?php
include 'backend/connect.php';

$id_ajuan = $_GET['id'] ?? null;

if ($id_ajuan) {
    $query = "
    SELECT a.*, i.nama_industri, s.nama_siswa 
    FROM ajuan_pkl a 
    JOIN industri i ON a.id_industri = i.id_industri 
    JOIN siswa s ON a.id_siswa = s.id_siswa 
    WHERE a.id_ajuan = '$id_ajuan'
    ";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        $row = null;
    }
} else {
    echo "ID ajuan tidak diberikan.";
    exit;
}

$status_message = '';
$title_message = '';
$title_class = '';
if ($row) {
    if ($row['status'] == 'disetujui') {
        $title_message = "SELAMAT◝(ᵔᗜᵔ)◜";
        $status_message = "Selamat, Anda diterima di industri: " . htmlspecialchars($row['nama_industri']) . ".";
        $title_class = 'status-approved'; 
    } elseif ($row['status'] == 'ditolak') {
        $title_message = "MAAF (ᴗ_ ᴗ。)";
        $status_message = "Maaf, Anda tidak relevan untuk industri: " . htmlspecialchars($row['nama_industri']) . ".";
        $title_class = 'status-rejected'; 
    } else {
        $title_message = "Status belum ditentukan (っ˕ -｡)ᶻ 𝗓 𐰁";
        $status_message = "Status belum ditentukan.";
    }
} else {
    echo "Data tidak ditemukan.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Ajuan PKL</title>
    <link rel="stylesheet" href="assets/css/detail.css">
    <style>
        .status-approved {
            color: blue; 
        }

        .status-rejected {
            color: red; 
        }
    </style>
</head>
<body>
    <div id="modal-overlay" class="modal-overlay"></div>

    <div id="modal-content" class="modal">
        <div class="modal-header">
            <h1 class="<?php echo $title_class; ?>"><?php echo $title_message; ?></h1>
            <span class="close-button">ᯓ★</span>
        </div>
        <div class="modal-body">
            <div class="siswa-details">
                <table class="siswa-table">
                    <tr>
                        <td>ID Ajuan</td>
                        <td><?php echo htmlspecialchars($row['id_ajuan']); ?></td>
                    </tr>
                    <tr>
                        <td>Nama Siswa</td>
                        <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                    </tr>
                    <tr>
                        <tr>
                            <td>Nama Industri</td>
                            <td><?php echo htmlspecialchars($row['nama_industri']); ?></td>
                        </tr>
                        <td>Tanggal Mulai</td>
                        <td><?php echo htmlspecialchars($row['tanggal_mulai']); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Selesai</td>
                        <td><?php echo htmlspecialchars($row['tanggal_selesai']); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Pengajuan</td>
                        <td><?php echo htmlspecialchars($row['tanggal_pengajuan']); ?></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td><?php echo $status_message; ?></td>
                    </tr>
                </table>
                <div class="kembali-button">
                    <a href="hasil_pkl.php"><i class="fas fa-arrow-left"></i> Kembali</a> 
                </div>
                <?php if ($row['status'] == 'disetujui') : ?>
                <div class="print-button">
                    <button onclick="window.print()">Cetak Hasil</button>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>
</html>