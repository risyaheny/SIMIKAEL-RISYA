-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Feb 2025 pada 08.06
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pengajuan_pkl`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `ajuan_pkl`
--

CREATE TABLE `ajuan_pkl` (
  `id_ajuan` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_industri` int(11) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `tanggal_pengajuan` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','disetujui','ditolak','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `ajuan_pkl`
--

INSERT INTO `ajuan_pkl` (`id_ajuan`, `id_siswa`, `id_industri`, `tanggal_mulai`, `tanggal_selesai`, `tanggal_pengajuan`, `status`) VALUES
(3, 30, 12, '2025-02-24', '2025-02-18', '2025-02-18 07:07:04', 'disetujui'),
(4, 30, 12, '2025-02-17', '2025-03-03', '2025-02-18 07:08:47', 'disetujui'),
(5, 30, 12, '2025-02-01', '2025-03-01', '2025-02-18 06:01:57', 'ditolak'),
(6, 30, 1, '2025-02-01', '2025-02-24', '2025-02-18 06:06:44', 'disetujui'),
(7, 10, 1, '2025-02-01', '2025-02-28', '2025-02-18 06:04:56', 'disetujui'),
(8, 10, 12, '2025-02-18', '2025-03-08', '2025-02-18 05:59:16', 'disetujui'),
(9, 10, 1, '2025-02-18', '2025-02-18', '2025-02-18 07:02:35', 'disetujui'),
(10, 5, 2, '2025-01-30', '2025-03-08', '2025-02-17 17:00:00', 'disetujui'),
(11, 19, 3, '2025-03-01', '2025-04-01', '2025-02-18 01:24:43', 'ditolak'),
(12, 19, 1, '2025-02-19', '2025-02-28', '2025-02-19 09:03:29', 'pending');

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `id_guru` int(11) NOT NULL,
  `nama_guru` varchar(100) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `bidang` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id_guru`, `nama_guru`, `nip`, `bidang`) VALUES
(900000, 'Pak andhen', '123', 'Informatika');

-- --------------------------------------------------------

--
-- Struktur dari tabel `industri`
--

CREATE TABLE `industri` (
  `id_industri` int(11) NOT NULL,
  `nama_industri` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `kontak` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `industri`
--

INSERT INTO `industri` (`id_industri`, `nama_industri`, `alamat`, `kontak`) VALUES
(1, 'BPTIK', 'Semarang', '0852-2628-0062'),
(2, 'Can Creative', 'semarang', '8529090293'),
(3, 'Bapak pucung', 'semarang', '0874'),
(4, 'Diskominfo', 'semarang', '8529090'),
(12, 'USMTV', 'semarang', '852909029302930');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int(11) NOT NULL,
  `nama_siswa` varchar(100) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `jurusan` varchar(50) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nama_siswa`, `nis`, `kelas`, `jurusan`, `id_user`) VALUES
(5, 'Aufa Citra', '2454', '9 smk', 'RPL', 3),
(10, 'Evacahya', '2457', '12', 'RPL 1', 2),
(19, 'Lutfiah Nur', '32145', '3 smk', 'RPL 2', 4),
(30, 'Risya Heny P.S', '22174', 'XII', 'RPL', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('siswa','admin','guru','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `role`) VALUES
(1, 'siswa1', '$2y$10$kYHkfv2xE3gXBiGSWqlHkucopj/opl7e3IOAq7LJCF8Tc9A5.Ia0C', 'siswa'),
(3, 'guru1', '$2y$10$kKrEj6x3XQeTF23hMvgfS..hEHg98/uh0pO9hVIHeoWq4szoR674u', 'guru'),
(5, 'adminpkl', '$2y$10$qwn8/VFGFW9yCLlHJSIC7Or0LsXagNfpUjXQJdgeb2TkuYz5ZqGsK', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `ajuan_pkl`
--
ALTER TABLE `ajuan_pkl`
  ADD PRIMARY KEY (`id_ajuan`),
  ADD KEY `id_siswa` (`id_siswa`,`id_industri`),
  ADD KEY `id_industri` (`id_industri`);

--
-- Indeks untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`id_guru`);

--
-- Indeks untuk tabel `industri`
--
ALTER TABLE `industri`
  ADD PRIMARY KEY (`id_industri`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `ajuan_pkl`
--
ALTER TABLE `ajuan_pkl`
  MODIFY `id_ajuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `guru`
--
ALTER TABLE `guru`
  MODIFY `id_guru` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=900001;

--
-- AUTO_INCREMENT untuk tabel `industri`
--
ALTER TABLE `industri`
  MODIFY `id_industri` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id_siswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `ajuan_pkl`
--
ALTER TABLE `ajuan_pkl`
  ADD CONSTRAINT `ajuan_pkl_ibfk_1` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`),
  ADD CONSTRAINT `ajuan_pkl_ibfk_2` FOREIGN KEY (`id_industri`) REFERENCES `industri` (`id_industri`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
