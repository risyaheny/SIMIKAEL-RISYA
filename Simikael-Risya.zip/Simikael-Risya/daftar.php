<?php
include 'backend/connect.php';
session_start();

$allowed_roles = ['siswa'];

if (!isset($_SESSION['id_user']) || !in_array($_SESSION['role'], $allowed_roles)) {
  header("Location: login/sign-in-up.php"); // Redirect jika bukan admin atau belum login
  exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $tanggal_mulai = mysqli_real_escape_string($conn, $_POST['tanggal_mulai']);
  $id_siswa = mysqli_real_escape_string($conn, $_POST['id_siswa']);
  $tanggal_selesai = mysqli_real_escape_string($conn, $_POST['tanggal_selesai']);
  $id_industri = mysqli_real_escape_string($conn, $_POST['id_industri']);
  $tanggal_pengajuan = mysqli_real_escape_string($conn, $_POST['tanggal_pengajuan']);

  $id_ajuan = uniqid('ajuan_pkl');
  $tanggal_pengajuan = date('Y-m-d H:i:s');

  if (empty($tanggal_mulai) || empty($id_siswa) || empty($tanggal_selesai) || empty($id_industri)) {
      echo "Error: Semua field harus diisi.";
      exit; 
  }

  $sql = "INSERT INTO ajuan_pkl (id_ajuan, tanggal_mulai, id_siswa, tanggal_selesai, id_industri, tanggal_pengajuan)
          VALUES (?, ?, ?, ?, ?, ?)";

  $stmt = mysqli_prepare($conn, $sql);
  if ($stmt) {
      mysqli_stmt_bind_param($stmt, "ssssss", $id_ajuan, $tanggal_mulai, $id_siswa, $tanggal_selesai, $id_industri, $tanggal_pengajuan);

      if (mysqli_stmt_execute($stmt)) {
          echo "<script>alert('Data berhasil disimpan!'); window.location.href='hasil_pkl.php';</script>";
          exit;
      } else {
          echo "Error: " . mysqli_stmt_error($stmt);
      }

      mysqli_stmt_close($stmt);
  } else {
      echo "Error: " . mysqli_error($conn);
  }

  mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Ajuan PKL</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: HeroBiz
  * Template URL: https://bootstrapmade.com/herobiz-bootstrap-business-template/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="starter-page-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid position-relative d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center me-auto me-xl-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1 class="sitename">𝕊𝕀𝕄𝕀𝕂✮𝔼𝕃</h1>
        <span>.</span>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="daftar.php" class="active">Daftar</a></li>
          <li><a href="hasil_pkl.php">Hasil</a></li>
          <li><a href="index_login.php#home">Beranda<br></a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      <a class="btn-getstarted" href="login/logout.php">Log Out</a>

    </div>
  </header>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title">
      <div class="container d-lg-flex justify-content-between align-items-center">
        <h1 class="mb-2 mb-lg-0">Ayo Daftar!!</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index_login.php">Home</a></li>
            <li class="current">Daftar</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Starter Section Section -->
    <section id="starter-section" class="starter-section section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Formulir Pengajuan PKL</h2>
      </div><!-- End Section Title -->

  <form id="formAjuanPKL" action="daftar.php" method="POST">
    <fieldset>
      <div class="row mb-3">
            <div class="col-md-6">
              <label for="id_ajuan">ID Ajuan:</label>
              <input type="text" id="id_ajuan" name="id_ajuan" placeholder="Otomatis terisi..." readonly>
          </div>

            <div class="col-md-6">
              <label for="tanggal_mulai">Tanggal Mulai:</label>
              <input type="date" id="tanggal_mulai" name="tanggal_mulai" required>
            </div>
          </div>

          <div class="row mb-3">
            <div class="col-md-6">
              <label for="id_siswa">ID Siswa:</label>
              <select id="id_siswa" name="id_siswa" required>
                <option value="">-- Pilih Siswa --</option>
                <?php
                  include 'backend/connect.php';
                  $sql_siswa = "SELECT id_siswa, nama_siswa FROM siswa";
                  $result_siswa = mysqli_query($conn, $sql_siswa);
                  if (mysqli_num_rows($result_siswa) > 0) {
                    while($row = mysqli_fetch_assoc($result_siswa)) {
                      echo "<option value='" . $row["id_siswa"]. "'>" . $row["nama_siswa"]. "</option>";
                    }
                  }
                  mysqli_close($conn);
                ?>
              </select>
            </div>

              <div class="col-md-6">
                <label for="tanggal_selesai">Tanggal Selesai:</label>
                <input type="date" id="tanggal_selesai" name="tanggal_selesai" required>
              </div>
            </div>

          <div class="row mb-3">
            <div class="col-md-6">
              <label for="id_industri">ID Industri:</label>
              <select id="id_industri" name="id_industri" required>
                  <option value="">-- Pilih Industri --</option>
                  <?php
                    include 'backend/connect.php';
                    $sql_industri = "SELECT id_industri, nama_industri FROM industri";
                    $result_industri = mysqli_query($conn, $sql_industri);
                    if (mysqli_num_rows($result_industri) > 0) {
                      while($row = mysqli_fetch_assoc($result_industri)) {
                        echo "<option value='" . $row["id_industri"]. "'>" . $row["nama_industri"]. "</option>";
                      }
                    }
                    mysqli_close($conn);
                  ?>
              </select>
          </div>

            <div class="col-md-6">
              <label for="tanggal_pengajuan">Tanggal Pengajuan:</label>
              <input type="date" id="tanggal_pengajuan" name="tanggal_pengajuan" value="<?php echo date('Y-m-d'); ?>" readonly>
            </div>
          </div>

            <div class="buttons">
                <button type="submit">Ajukan PKL</button>
                <button type="reset">Reset</button>
            </div>
      
    </fieldset>
  </form>

  </main>

  <footer id="footer" class="footer dark-background">

    <div class="footer-top">
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-4 col-md-6 footer-about">
            <a href="index.html" class="logo d-flex align-items-center">
              <span class="sitename">𝕊𝕀𝕄𝕀𝕂✮𝔼𝕃</span>
            </a>
            <div class="footer-contact pt-3">
              <p>Jl. Kokrosono No.75, Panggung Kidul</p>
              <p>Kota Semarang, Jawa Tengah 50178</p>
              <p class="mt-3"><strong>Phone:</strong> <span> (024) 3515701</span></p>
              <p><strong>Email:</strong> <span>info@example.com</span></p>
            </div>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">About us</a></li>
              <li><a href="#">Learn</a></li>
              <li><a href="#">Gallery</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-3 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Web Development</a></li>
              <li><a href="#">Product Management</a></li>
              <li><a href="#">Marketing</a></li>
              <li><a href="#">Graphic Design</a></li>
            </ul>
          </div>

        </div>
      </div>
    </div>

    <div class="copyright text-center">
      <div class="container d-flex flex-column flex-lg-row justify-content-center justify-content-lg-between align-items-center">

        <div class="d-flex flex-column align-items-center align-items-lg-start">
          <div>
            © Copyright <strong><span>𝕊𝕀𝕄𝕀𝕂✮𝔼𝕃</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/herobiz-bootstrap-business-template/ -->
            Designed by <a href="">Risya Heny</a>
          </div>
        </div>

        <div class="social-links order-first order-lg-last mb-3 mb-lg-0">
          <a href=""><i class="bi bi-twitter-x"></i></a>
          <a href=""><i class="bi bi-facebook"></i></a>
          <a href=""><i class="bi bi-instagram"></i></a>
          <a href=""><i class="bi bi-linkedin"></i></a>
        </div>

      </div>
    </div>

  </footer>


  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
function resetForm() {
    document.getElementById("formAjuanPKL").reset();
    
    // Pastikan tanggal pengajuan tetap di-set ke hari ini setelah reset
    document.getElementById("tanggal_pengajuan").value = "<?php echo date('Y-m-d '); ?>";
}
</script>

</body>
</html>